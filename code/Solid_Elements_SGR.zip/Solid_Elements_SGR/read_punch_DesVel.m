function [DES_VEL,DISP] = read_punch_DesVel(filename,N_Vars)
% filename='cantilevertipload';
directory=pwd;
%

N=165;
% N_Vars = 6;
DISP = zeros(N,6);
DES_VEL = zeros(N,3,N_Vars);

fid = fopen([directory,'\',filename,'.pch'],'r');

astring = fgetl(fid);
astring = fgetl(fid);
astring = fgetl(fid);
astring = fgetl(fid);
astring = fgetl(fid);
astring = fgetl(fid);
    
for nodes = 1:N
    astring = fgetl(fid);
    A = sscanf(astring,'%d %*s %e %e %e',[1,4]);
    astring = fgetl(fid);
    A1 = sscanf(astring,'%*s %e %e %e',[1,3]);
    DISP(A(1),:) = [A(2:end) A1];
end

for i = 1:N_Vars
    astring = fgetl(fid);
    astring = fgetl(fid);
    astring = fgetl(fid);
    astring = fgetl(fid);
    astring = fgetl(fid);
    astring = fgetl(fid);
    %
    for nodes = 1:N
        astring = fgetl(fid);
        A = sscanf(astring,'%d %*s %e %e %e',[1,4]);
        astring = fgetl(fid);
        DES_VEL(A(1),:,i) = A(2:end);
    end
end
%
fclose(fid);
end