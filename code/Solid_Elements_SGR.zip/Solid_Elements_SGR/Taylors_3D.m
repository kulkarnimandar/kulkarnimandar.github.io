function [dPHIdx,dPHIdy,dPHIdz,PHI0,Rank_def_flag] = Taylors_3D(xp,yp,zp,phip,xa,ya,za,phia)
%
if isempty(phia)
    phia_unknown = 1;
    phia = 0;
else 
    phia_unknown = 0;
end
%
if find(xp==xa & yp==ya & zp==za)
    ind = find(xp==xa & yp==ya & zp==za);
    rest_ind = setdiff(1:length(xp),ind);
    xp = xp(rest_ind);
    yp = yp(rest_ind);
    zp = zp(rest_ind);
    phip = phip(rest_ind);
end
%
C = [ ones(length(xp),1) , (xp-xa) , (yp-ya) , (zp-za) , ... % Constant and first order terms
          1/2*(xp-xa).^2 , 1/2*(yp-ya).^2 , 1/2*(zp-za).^2 , ... % Half of the second order terms
          (xp-xa).*(yp-ya) , (yp-ya).*(zp-za) , (zp-za).*(xp-xa)];%, ... % Rest of the second order terms
          %1/6*(xp-xa).^3 , 1/6*(yp-ya).^3 , 1/6*(zp-za).^3 , ... % First set of third order terms
          %1/2*(xp-xa).^2.*(yp-ya) , 1/2*(xp-xa).^2.*(zp-za) , 1/2*(yp-ya).^2.*(zp-za) , 1/2*(yp-ya).^2.*(xp-xa) , 1/2*(zp-za).^2.*(xp-xa) , 1/2*(zp-za).^2.*(yp-ya) , ... % Second set of third order terms
          %(xp-xa).*(yp-ya).*(zp-za)];
%
d = phip-phia;
%
if phia_unknown == 0
    C = C(:,2:end);
end
%
if rank(C)<min(size(C)), Rank_def_flag=1; else Rank_def_flag=0; end
SpacGrad = C\d;
%
if phia_unknown == 0
    PHI0 = phia;
    dPHIdx = SpacGrad(1);
    dPHIdy = SpacGrad(2);
    dPHIdz = SpacGrad(3);
else
    PHI0 = SpacGrad(1);
    dPHIdx = SpacGrad(2);
    dPHIdy = SpacGrad(3);
    dPHIdz = SpacGrad(4);
end