function [DISP,ELEM_DATA] = read_punch(Model,filename)
%
DOF = Model.DOF;
CONN = Model.CONN;
%
ID = cell(1,length(CONN));
CONNEC = cell(1,length(CONN));
CENTLOC = cell(1,length(CONN));
GAUSSLOC = cell(1,length(CONN));
CENTSTR = zeros(1,6);
GAUSSSTR = zeros(8,6);
for i = 1:length(CONN)
    ID{1,i}=CONN(i,1);
    CONNEC{1,i}=CONN(i,2:end);
    [xyz_Center,xyz_Gauss]=Get_Center_Gauss_loc(DOF,CONN,CONN(i,1));
    CENTLOC{1,i}= xyz_Center.';
    GAUSSLOC{1,i}= xyz_Gauss;
end
ELEM_DATA = struct('ID',ID,'CONNEC',CONNEC,'CENTLOC',CENTLOC, ...
                   'CENTSTR',CENTSTR,'GAUSSLOC',GAUSSLOC,'GAUSSSTR',GAUSSSTR);
%
%
% nx = Model.nx;
% ny = Model.ny;
% DOF = Model.DOF;
% DOF=165;
% NumEl=80;

% DISP = zeros(length(DOF),6);
DISP = zeros(size(DOF,1),6);
% FORCES = zeros(nx*ny,8);

fid = fopen([filename,'.pch'],'r');

astring = fgetl(fid);
astring = fgetl(fid);
astring = fgetl(fid);
astring = fgetl(fid);
astring = fgetl(fid);
astring = fgetl(fid);
    
for nodes = 1:size(DOF,1)
    astring = fgetl(fid);
    A = sscanf(astring,'%d %*s %e %e %e',[1,4]);
    astring = fgetl(fid);
    A1 = sscanf(astring,'%*s %e %e %e',[1,3]);
    DISP(A(1),:) = [A(2:end) A1];
end

astring = fgetl(fid);
astring = fgetl(fid);
astring = fgetl(fid);
astring = fgetl(fid);
astring = fgetl(fid);
astring = fgetl(fid);
astring = fgetl(fid);

for el = 1:size(CONN,1)
    astring = fgetl(fid);
    A0 = sscanf(astring,'%d',[1,1]);
    STRESS = zeros(9,6);
    for i=1:9
        astring = fgetl(fid);
        A1 = sscanf(astring,'%*s %d %e %e',[1,3]);
        astring = fgetl(fid);
        A2 = sscanf(astring,'%*s %e %e %e',[1,3]);
        astring = fgetl(fid);
        A3 = sscanf(astring,'%*s %e %e %e',[1,3]);
        astring = fgetl(fid);
        A4 = sscanf(astring,'%*s %e %e %e',[1,3]);
        astring = fgetl(fid);
        A5 = sscanf(astring,'%*s %e %e %e',[1,3]);
        astring = fgetl(fid);
        A6 = sscanf(astring,'%*s %e %e %e',[1,3]);
        astring = fgetl(fid);
        A7 = sscanf(astring,'%*s %e %e %e',[1,3]);
        STRESS(i,:) = [A1(2) A4(1) A6(1) A1(3) A4(2) A6(2)];
    end
    ELEM_DATA(el).CENTSTR = STRESS(1,:);
    ELEM_DATA(el).GAUSSSTR = STRESS(2:9,:);
end
fclose(fid);
end
% save('STRESS_CHEXA.mat','STRESS','DISP');

% Locations of Element center and Gauss points
function [xyz_Center,xyz_Gauss]=Get_Center_Gauss_loc(DOF,CONN,EL_ID)
% load('DOF.mat');
% load('CONN.mat');
%
N1 = @(xi,et,zt) (1 - xi)*(1 - et)*(1 - zt)/8;
N2 = @(xi,et,zt) (1 + xi)*(1 - et)*(1 - zt)/8;
N3 = @(xi,et,zt) (1 + xi)*(1 + et)*(1 - zt)/8;
N4 = @(xi,et,zt) (1 - xi)*(1 + et)*(1 - zt)/8;
N5 = @(xi,et,zt) (1 - xi)*(1 - et)*(1 + zt)/8;
N6 = @(xi,et,zt) (1 + xi)*(1 - et)*(1 + zt)/8;
N7 = @(xi,et,zt) (1 + xi)*(1 + et)*(1 + zt)/8;
N8 = @(xi,et,zt) (1 - xi)*(1 + et)*(1 + zt)/8;
%
CoodMat = @(a) [ -a , -a , -a;
                 +a , -a , -a;
                 +a , +a , -a;
                 -a , +a , -a;
                 -a , -a , +a;
                 +a , -a , +a;
                 +a , +a , +a;
                 -a , +a , +a ];
%
N = @(xi,et,zt) [N1(xi,et,zt) 0 0 N2(xi,et,zt) 0 0 N3(xi,et,zt) 0 0 N4(xi,et,zt) 0 0 N5(xi,et,zt) 0 0 N6(xi,et,zt) 0 0 N7(xi,et,zt) 0 0 N8(xi,et,zt) 0 0;
              0 N1(xi,et,zt) 0 0 N2(xi,et,zt) 0 0 N3(xi,et,zt) 0 0 N4(xi,et,zt) 0 0 N5(xi,et,zt) 0 0 N6(xi,et,zt) 0 0 N7(xi,et,zt) 0 0 N8(xi,et,zt) 0;
              0 0 N1(xi,et,zt) 0 0 N2(xi,et,zt) 0 0 N3(xi,et,zt) 0 0 N4(xi,et,zt) 0 0 N5(xi,et,zt) 0 0 N6(xi,et,zt) 0 0 N7(xi,et,zt) 0 0 N8(xi,et,zt)];
%
nodeInd = CONN(EL_ID,2:9);
xyzMat = DOF(nodeInd,2:4).';
xyz_Center=N(0,0,0)*xyzMat(:);
%
xyz_Nodes = zeros(8,3);
xyz_Gauss = zeros(8,3);
for i=1:8
    Cood_Nodes = CoodMat(1);
    xyz_Nodes(i,:)=N(Cood_Nodes(i,1),Cood_Nodes(i,2),Cood_Nodes(i,3))*xyzMat(:);
    Cood_Gauss = CoodMat(1/sqrt(3));
    xyz_Gauss(i,:)=N(Cood_Gauss(i,1),Cood_Gauss(i,2),Cood_Gauss(i,3))*xyzMat(:);
end
% figure()
% plot3(xyz_Nodes(:,1),xyz_Nodes(:,2),xyz_Nodes(:,3),'bo');
% hold on;
% plot3(xyz_Center(1),xyz_Center(2),xyz_Center(3),'gd');
% plot3(xyz_Gauss(:,1),xyz_Gauss(:,2),xyz_Gauss(:,3),'r*');
% grid on;
% xlabel('x');ylabel('y');zlabel('z');
% axis([0 10 0 2 0 4]);
end