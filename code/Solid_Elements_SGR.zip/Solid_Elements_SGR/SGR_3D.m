function [dDISP,dSTRESS,NSTRESS,N_warnings] = SGR_3D(Model)
n_layer = Model.n_layer;
N_warnings=0;
DOF = Model.DOF;
CONN = Model.CONN;
DISP = Model.DISP;
ELEM_DATA = Model.ELEM_DATA;
dx = Model.dx;
dy = Model.dy;
dz = Model.dz;
%
% Matrix of element center locations
EL_CENT = zeros(length(CONN),4);
for j = 1:length(CONN)
    EL_CENT(j,1) = ELEM_DATA(j).ID;
    EL_CENT(j,2:4) = ELEM_DATA(j).CENTLOC;
end
%% DISPLACEMENT GRADIENTS
%
dDISPdx = zeros(length(DOF),6);
dDISPdy = zeros(length(DOF),6);
dDISPdz = zeros(length(DOF),6);
for i = 1:length(DOF)
    xa = DOF(i,2);
    ya = DOF(i,3);
    za = DOF(i,4);
    ind = ((abs(DOF(:,2) - xa)<=n_layer*dx) .* ...
           (abs(DOF(:,3) - ya)<=n_layer*dy) .* ...
           (abs(DOF(:,4) - za)<=n_layer*dz));
    nodes = find(ind);
    xp = DOF(nodes,2);
    yp = DOF(nodes,3);
    zp = DOF(nodes,4);
    phip_mat = DISP(nodes,:);
    %
    for j = 1:6
        phip = phip_mat(:,j);
        phia = DISP(i,j);
        [dPHIdx,dPHIdy,dPHIdz,~,Rank_def_flag] = Taylors_3D(xp,yp,zp,phip,xa,ya,za,phia);
        if Rank_def_flag==1, N_warnings=N_warnings+1; end
        dDISPdx(i,j) = dPHIdx;
        dDISPdy(i,j) = dPHIdy;
        dDISPdz(i,j) = dPHIdz;
    end
end

%% SHEAR STRESS GRADIENTS (using Center Points)
%
NSTRESS = zeros(length(DOF),6);
dSTRESSdx = zeros(length(DOF),6);
dSTRESSdy = zeros(length(DOF),6);
dSTRESSdz = zeros(length(DOF),6);
for i = 1:length(DOF) % Change to i = 1:length(CONN) for comparing to 1D-SGR
    xa = DOF(i,2); 
    ya = DOF(i,3);
    za = DOF(i,4);
    ind = ((abs(EL_CENT(:,2) - xa)<=1*dx) .* ...
                (abs(EL_CENT(:,3) - ya)<=1*dy) .* ...
                (abs(EL_CENT(:,4) - za)<=4*dz));
    patch_elems = find(ind);
    xyz_Center = zeros(1*length(patch_elems),3);
    Stress_Center = zeros(1*length(patch_elems),6);
    % Extract stress data at center points of the chosen elements.
    for ii = 1:length(patch_elems)
        xyz_Center_holder = ELEM_DATA(patch_elems(ii)).CENTLOC;
        xyz_Center((ii-1)*1+1:ii*1,:) = xyz_Center_holder;
        Stress_Center_holder = ELEM_DATA(patch_elems(ii)).CENTSTR;
        Stress_Center((ii-1)*1+1:ii*1,:) = Stress_Center_holder;
    end
    % Find the nodes on BCs and add data points from boundaries
    node_list1 = Model.CONN(patch_elems,2:9);
    node_list = unique(node_list1(:));
    [BC_nodes,row_num] = intersect(Model.StressBC(:,1),node_list);
    for j = 4:6
        [exp_node,row_num_exp] = intersect(Model.StressBC(:,1),DOF(i,1));
        if ~isempty(exp_node)
            phi0 = Model.StressBC(row_num_exp,j+1);
            if ~isnan(phi0)
                phia = phi0;
            else
                phia = [];
            end
        else
            phia = [];
        end
        %
        xp = xyz_Center(:,1);
        yp = xyz_Center(:,2);
        zp = xyz_Center(:,3);
        phip = Stress_Center(:,j);
        for k = 1:length(BC_nodes)
            if ~isnan(Model.StressBC(row_num(k),j+1))
                xp(end+1) = DOF(BC_nodes(k),2);
                yp(end+1) = DOF(BC_nodes(k),3);
                zp(end+1) = DOF(BC_nodes(k),4);
                phip(end+1) = Model.StressBC(row_num(k),j+1);
            end
        end
        %
        [dPHIdx,dPHIdy,dPHIdz,PHI0,Rank_def_flag] = Taylors_3D(xp,yp,zp,phip,xa,ya,za,phia);
        if Rank_def_flag==1, N_warnings=N_warnings+1; end
        dSTRESSdx(i,j) = dPHIdx;
        dSTRESSdy(i,j) = dPHIdy;
        dSTRESSdz(i,j) = dPHIdz;
        NSTRESS(i,j) = PHI0;
    end
end
%% NORMAL STRESS GRADIENTS (using Gauss Points)
%
for i = 1:length(DOF) % Change to i = 1:length(CONN) for comparing to 1D-SGR
    xa = DOF(i,2); 
    ya = DOF(i,3);
    za = DOF(i,4);
    ind = ((abs(EL_CENT(:,2) - xa)<=1*dx) .* ...
                (abs(EL_CENT(:,3) - ya)<=1*dy) .* ...
                (abs(EL_CENT(:,4) - za)<=4*dz));
    patch_elems = find(ind);
    xyz_Gauss = zeros(8*length(patch_elems),3);
    Stress_Gauss = zeros(8*length(patch_elems),6);
    % Extract stress data at center points of the chosen elements.
    for ii = 1:length(patch_elems)
        xyz_Gauss_holder = ELEM_DATA(patch_elems(ii)).GAUSSLOC;
        xyz_Gauss((ii-1)*8+1:ii*8,:) = xyz_Gauss_holder;
        Stress_Gauss_holder = ELEM_DATA(patch_elems(ii)).GAUSSSTR;
        Stress_Gauss((ii-1)*8+1:ii*8,:) = Stress_Gauss_holder;
    end
    % Find the nodes on BCs and add data points from boundaries
    node_list1 = Model.CONN(patch_elems,2:9);
    node_list = unique(node_list1(:));
    [BC_nodes,row_num] = intersect(Model.StressBC(:,1),node_list);
    for j = 1:3
        [exp_node,row_num_exp] = intersect(Model.StressBC(:,1),DOF(i,1));
        if ~isempty(exp_node)
            phi0 = Model.StressBC(row_num_exp,j+1);
            if ~isnan(phi0)
                phia = phi0;
            else
                phia = [];
            end
        else
            phia = [];
        end
        %
        xp = xyz_Gauss(:,1);
        yp = xyz_Gauss(:,2);
        zp = xyz_Gauss(:,3);
        phip = Stress_Gauss(:,j);
        for k = 1:length(BC_nodes)
            if ~isnan(Model.StressBC(row_num(k),j+1))
                xp(end+1) = DOF(BC_nodes(k),2);
                yp(end+1) = DOF(BC_nodes(k),3);
                zp(end+1) = DOF(BC_nodes(k),4);
                phip(end+1) = Model.StressBC(row_num(k),j+1);
            end
        end
        %
        [dPHIdx,dPHIdy,dPHIdz,PHI0,Rank_def_flag] = Taylors_3D(xp,yp,zp,phip,xa,ya,za,phia);
        if Rank_def_flag==1, N_warnings=N_warnings+1; end
        dSTRESSdx(i,j) = dPHIdx;
        dSTRESSdy(i,j) = dPHIdy;
        dSTRESSdz(i,j) = dPHIdz;
        NSTRESS(i,j) = PHI0;
    end
end
%% STRESS GRADIENTS (togther shear and normal using gauss points)
% This sets the expansion point value to zero at the side faces, and uses
% only Gauss point stresses.

%
% NSTRESS = zeros(length(DOF),6);
% dSTRESSdx = zeros(length(DOF),6);
% dSTRESSdy = zeros(length(DOF),6);
% dSTRESSdz = zeros(length(DOF),6);
% % dSTRESSdx = zeros(length(CONN),6); % Just for comparing to 1D-SGR
% % dSTRESSdy = zeros(length(CONN),6);
% % dSTRESSdz = zeros(length(CONN),6);
% %
% % N_elem = 80; % =56 works best for point of expansion at the element centers.. for comparing with 1-D SGR result
% %
% for i = 1:length(DOF) % Change to i = 1:length(CONN) for comparing to 1D-SGR
%     xa = DOF(i,2); 
%     ya = DOF(i,3);
%     za = DOF(i,4);
% %     xa = EL_CENT(i,2);% Just for comparing to 1D-SGR
% %     ya = EL_CENT(i,3);
% %     za = EL_CENT(i,4);
% %    ExpPointInPatch_flag = 0; % ExpPointInPatch_flag=1 means expansion point is in the patch.
% %     dist = sqrt( (EL_CENT(:,2)-xa).^2 + (EL_CENT(:,3)-ya).^2 + (EL_CENT(:,4)-za).^2 );
% %     [VALS,INDS] = sort(dist);
% %     nodes = INDS(1:N_elem); % Choose 5 nearest elements.    
%     ind = ((abs(EL_CENT(:,2) - xa)<=5*dx) .* ...
%                 (abs(EL_CENT(:,3) - ya)<=2*dy) .* ...
%                 (abs(EL_CENT(:,4) - za)<=5*dz));
%     nodes = find(ind);
%     xyz_Gauss = zeros(8*length(nodes),3);
%     Stress_Gauss = zeros(8*length(nodes),6);
%     % Extract stress data at Gauss points of the chosen elements.
%     for ii = 1:length(nodes)
%         xyz_Gauss_holder = ELEM_DATA(nodes(ii)).GAUSSLOC;
%         xyz_Gauss((ii-1)*8+1:ii*8,:) = xyz_Gauss_holder;
%         Stress_Gauss_holder = ELEM_DATA(nodes(ii)).GAUSSSTR;
%         Stress_Gauss((ii-1)*8+1:ii*8,:) = Stress_Gauss_holder;
%     end
%     xp = xyz_Gauss(:,1);
%     yp = xyz_Gauss(:,2);
%     zp = xyz_Gauss(:,3);
%     for j = 1:6
%         phip = Stress_Gauss(:,j);
%         if ~isempty(find(Model.NoStressNodes==DOF(i,1),1)) && (j~=1)
%             phia = 0;
%         else
%             phia = [];
%         end
%         [dPHIdx,dPHIdy,dPHIdz,PHI0,Rank_def_flag] = Taylors_3D(xp,yp,zp,phip,xa,ya,za,phia);
%         if Rank_def_flag==1, N_warnings=N_warnings+1; end
%         dSTRESSdx(i,j) = dPHIdx;
%         dSTRESSdy(i,j) = dPHIdy;
%         dSTRESSdz(i,j) = dPHIdz;
%         NSTRESS(i,j) = PHI0;
%     end
% end

%
%% Plotting etc
% figure()
% set(gcf,'defaultlinelinewidth',2,'defaultaxesfontsize',17);
% plot(Normal_CSE_3D(2:3:end),0:1:4,'r-sq');
% xlabel('$\sigma^{\prime}_{X}\,\,[N/m^2]$','interpreter','latex','fontsize',20);
% ylabel('$z\,\,[m]$','interpreter','latex','fontsize',20);
% title('Normal pressure, CSE Load');
% axis([-inf inf 0 4]);
% legend(['SGR-3D, Ne=',num2str(N_elem)]);
% %
% figure()
% set(gcf,'defaultlinelinewidth',2,'defaultaxesfontsize',17);
% plot(Shear_CSE_3D(2:3:end),0:1:4,'r-sq');
% xlabel('$\tau^{\prime}_{ZX}\,\,[N/m^2]$','interpreter','latex','fontsize',20);ylabel('$z\,\,[m]$','interpreter','latex','fontsize',20);
% title('Shear traction, CSE Load');
% axis([-1.07 1.07 0 4]);
% legend(['SGR-3D, Ne=',num2str(N_elem)]);
% %
% figure()
% set(gcf,'defaultlinelinewidth',2,'defaultaxesfontsize',17);
% plot(Shear_CSE_3D_xy(2:3:end),0:1:4,'r-sq');
% xlabel('$\tau^{\prime}_{YX}\,\,[N/m^2]$','interpreter','latex','fontsize',20);ylabel('$z\,\,[m]$','interpreter','latex','fontsize',20);
% title('Shear traction, CSE Load');
% axis([-1.07 1.07 0 4]);
% legend(['SGR-3D, Ne=',num2str(N_elem)]);
%
dDISP(:,:,1) = dDISPdx;
dDISP(:,:,2) = dDISPdy;
dDISP(:,:,3) = dDISPdz;
dSTRESS(:,:,1) = dSTRESSdx;
dSTRESS(:,:,2) = dSTRESSdy;
dSTRESS(:,:,3) = dSTRESSdz;
%
% %% To check against 1D-SGR
% load('Normal_Shear_CSE.mat');
% Normal_CSE_3D = -1*dSTRESSdx(10:10:80,1);
% Shear_CSE_3D = -1*dSTRESSdx(10:10:80,6);
% [Normal_CSE.',Normal_CSE_3D]
% [Shear_CSE.',Shear_CSE_3D]
% % Plot for comparison of SGR_1D and SGR_3D
% figure()
% set(gcf,'defaultlinelinewidth',2,'defaultaxesfontsize',17);
% % plot([DOF(e1,4),DOF(e2,4),DOF(e3,4)],[dSTRESSdx(e1,1),dSTRESSdx(e2,1),dSTRESSdx(e3,1)],'-o');
% % hold on;
% % Elem_ceter_end = [ELEM_DATA(10).CENTLOC; ELEM_DATA(30).CENTLOC; ELEM_DATA(50).CENTLOC; ELEM_DATA(70).CENTLOC];
% plot(Normal_CSE(1:2:end),0.5:1:3.5,'b-o');
% hold on;
% plot(Normal_CSE_3D(1:2:end),0.5:1:3.5,'r-sq');
% xlabel('$\sigma^{\prime}_{X}\,\,[N/m^2]$','interpreter','latex','fontsize',20);
% ylabel('$z\,\,[m]$','interpreter','latex','fontsize',20);
% % set(gca, 'xdir','reverse');
% title('Normal pressure, CSE Load');
% legend('SGR-1D',['SGR-3D, Ne=',num2str(N_elem)]);
% axis([-inf inf 0 4]);
% %
% figure()
% set(gcf,'defaultlinelinewidth',2,'defaultaxesfontsize',17);
% plot(Shear_CSE(1:2:end),0.5:1:3.5,'b-o');
% hold on;
% plot(Shear_CSE_3D(1:2:end),0.5:1:3.5,'r-sq');
% xlabel('$\tau^{\prime}_{ZX}\,\,[N/m^2]$','interpreter','latex','fontsize',20);ylabel('$z\,\,[m]$','interpreter','latex','fontsize',20);
% title('Shear traction, CSE Load');
% axis([-inf inf 0 4]);
% legend('SGR-1D',['SGR-3D, Ne=',num2str(N_elem)]);
%
end