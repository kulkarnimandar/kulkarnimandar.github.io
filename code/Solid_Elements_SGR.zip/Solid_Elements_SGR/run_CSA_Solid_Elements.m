%% Call CSA_Solid_Elements for User Guide example dsoug6.dat design variables
clear; close all; clc;
load('DOF.mat');
load('CONN.mat');
dir_name = pwd;
filename = 'dsoug6_rollers_parabolic';
numLines_csa = 367;
numLines_primary = 383;
filename_bndshape = 'dsoug6_rollers_parabolic_bndshape';
N_Vars = 6;
n_layer = 10.1;
%% Data about boundaries, nodes, connectivity etc
Model.n_layer = n_layer;
Model.dx = DOF(2,2) - DOF(1,2);
Model.dy = DOF(12,3) - DOF(1,3);
Model.dz = DOF(34,4) - DOF(1,4);
Model.DOF = DOF;
Model.CONN = CONN;
tip          = [10,11,22,55,44;
                20,22,33,66,55
                30,44,55,88,77;
                40,55,66,99,88;
                50,77,88,121,110;
                60,88,99,132,121;
                70,110,121,154,143;
                80,121,132,165,154];
%             
top = [(61:70)'  (133:142)'  (134:143)' (145:154)' (144:153)';
       (71:80)'  (144:153)'  (145:154)'  (156:165)'  (155:164)'];
%   
bottom = [(1:10)'  (12:21)'  (13:22)'  (2:11)'  (1:10)';
          (11:20)'  (23:32)'  (24:33)'  (13:22)'  (12:21)'];
%      
left = [(1:10)'  (1:10)'  (2:11)'  (35:44)'  (34:43)';
        (21:30)'  (34:43)'  (35:44)'  (68:77)'  (67:76)';
        (41:50)'  (67:76)'  (68:77)'  (101:110)'  (100:109)';
        (61:70)'  (100:109)'  (101:110)'  (134:143)'  (133:142)'];
%   
right = [(11:20)'  (24:33)'  (23:32)'  (56:65)'  (57:66)';
         (31:40)'  (57:66)'  (56:65)'  (89:98)'  (90:99)';
         (51:60)'  (90:99)'  (89:98)'  (122:131)'  (123:132)';
         (71:80)'  (123:132)'  (122:131)'  (155:164)'  (156:165)'];          
%           
Model.Normal_order = [tip;
                top;
                bottom;
                left;
                right];
% Model.StressBC = [Node#,sigma_xx,sigma_yy,sigma_zz,tau_xy,tau_yz,tau_zx];
Model.StressBC = [(1:33)',repmat([NaN,NaN,0,NaN,0,0],33,1); % bottom surface
                  (133:165)',repmat([NaN,NaN,0,NaN,0,0],33,1); % top surface
                  (35:43)',repmat([NaN,0,NaN,0,0,NaN],9,1); % left side surface
                  (68:76)',repmat([NaN,0,NaN,0,0,NaN],9,1); % left side surface
                  (101:109)',repmat([NaN,0,NaN,0,0,NaN],9,1); % left side surface
                  (57:65)',repmat([NaN,0,NaN,0,0,NaN],9,1); % right side surface
                  (90:98)',repmat([NaN,0,NaN,0,0,NaN],9,1); % right side surface
                  (123:131)',repmat([NaN,0,NaN,0,0,NaN],9,1); % right side surface
                  [44,55,66]',repmat([0,NaN,NaN,0,NaN,-14.0625],3,1); % tip surface
                  [77,88,99]',repmat([0,NaN,NaN,0,NaN,-18.75],3,1); % tip surface
                  [110,121,132]',repmat([0,NaN,NaN,0,NaN,-14.0625],3,1); % tip surface
                  ];
% Model.NoStressNodes = [1:11, 12:22, 23:33, ... % bottom surface
%                        133:143, 144:154, 155:165, ... % top surface
%                        35:43, 68:76, 101:109 ... % left side surface
%                        57:65, 90:98, 123:131]; % right side surface
% Model.AppliedTraction = [ 44, -14.0625;
%                           55, -14.0625;
%                           66, -14.0625;
%                           77, -18.75;
%                           88, -18.75;
%                           99, -18.75;
%                          110, -14.0625;
%                          121, -14.0625;
%                          132, -14.0625];
%
Model.SPC=[1     1     0     0
    12     1     0     0
    23     1     0     0
    34     1     0     0
    45     1     2     3
    56     1     0     0
    67     1     2     3
    78     1     2     3
    89     1     2     3
   100     1     0     0
   111     1     2     3
   122     1     0     0
   133     1     0     0
   144     1     0     0
   155     1     0     0];
%
Model.SPC_Normal_order = [1      1     34     45    12
              12     12    45     56    23
              23     12    45     56    23
              34     34    67     78    45
              45     45    78     89    56
              56     45    78     89    56
              67     67    100    111   78
              78     78    111    122   89
              89     78    111    122   89
              100    100   133    144   111
              111    111   144    155   122
              122    111   144    155   122
              133    100   133    144   111
              144    111   144    155   122
              155    111   144    155   122];
%
Model.Boundary_nodes = [ 1:33, ... % bottom
                         133:165, ... % top
                         34:44, 67:77, 100:110, ... % left
                         56:66, 89:99, 122:132, ... % right
                         55:33:121, ... % tip
                         45:33:111]; % base
%% Design Velocities
[DES_VEL,DISP] = read_punch_DesVel(filename_bndshape,N_Vars);
DES_VEL_1(:,1) = DOF(:,1);
DES_VEL_2(:,1) = DOF(:,1);
DES_VEL_3(:,1) = DOF(:,1);
DES_VEL_4(:,1) = DOF(:,1);
DES_VEL_5(:,1) = DOF(:,1);
DES_VEL_6(:,1) = DOF(:,1);
%
DES_VEL_1(:,2:4) = DES_VEL(:,:,1);
DES_VEL_2(:,2:4) = DES_VEL(:,:,2);
DES_VEL_3(:,2:4) = DES_VEL(:,:,3);
DES_VEL_4(:,2:4) = DES_VEL(:,:,4);
DES_VEL_5(:,2:4) = DES_VEL(:,:,5);
DES_VEL_6(:,2:4) = DES_VEL(:,:,6);
% % To test if the new grid after first design cycle is what we expect from
% % the design velocities:
% % GNew_1 = DOF(:,2:4) + (9.93027985E-01 - 1)*(DES_VEL_1(:,2:4) + DES_VEL_2(:,2:4)) + ...
% %                       (1.10000002E+00 - 1)*(DES_VEL_3(:,2:4) + DES_VEL_4(:,2:4) + DES_VEL_5(:,2:4) + DES_VEL_6(:,2:4));
% % GNew_1(78:88,:)
%
if exist('Model1.mat','file') == 0
    Model.DES_VEL = DES_VEL_1;
    Model.case = 1;
    Model1=CSA_Solid_Elements(Model,dir_name,filename,numLines_csa,numLines_primary);
    save('Model1.mat','Model1');
    system(['copy ',[filename,'_cse'],'.bdf ',[filename,'_cse_dv1'],'.bdf']);
else load('Model1.mat'); 
end
%
if exist('Model2.mat','file') == 0
    Model.DES_VEL = DES_VEL_2;
    Model.case = 2;
    Model2=CSA_Solid_Elements(Model,dir_name,filename,numLines_csa,numLines_primary);
    save('Model2.mat','Model2');
    system(['copy ',[filename,'_cse'],'.bdf ',[filename,'_cse_dv2'],'.bdf']);
else load('Model2.mat'); 
end
%
if exist('Model3.mat','file') == 0
    Model.DES_VEL = DES_VEL_3;
    Model.case = 1;
    Model3=CSA_Solid_Elements(Model,dir_name,filename,numLines_csa,numLines_primary);
    save('Model3.mat','Model3');
    system(['copy ',[filename,'_cse'],'.bdf ',[filename,'_cse_dv3'],'.bdf']);
else load('Model3.mat'); 
end
%
if exist('Model4.mat','file') == 0
    Model.DES_VEL = DES_VEL_4;
    Model.case = 2;
    Model4=CSA_Solid_Elements(Model,dir_name,filename,numLines_csa,numLines_primary);
    save('Model4.mat','Model4');
    system(['copy ',[filename,'_cse'],'.bdf ',[filename,'_cse_dv4'],'.bdf']);
else load('Model4.mat'); 
end
%
if exist('Model5.mat','file') == 0
    Model.DES_VEL = DES_VEL_5;
    Model.case = 1;
    Model5=CSA_Solid_Elements(Model,dir_name,filename,numLines_csa,numLines_primary);
    save('Model5.mat','Model5');
    system(['copy ',[filename,'_cse'],'.bdf ',[filename,'_cse_dv5'],'.bdf']);
else load('Model5.mat'); 
end
%
if exist('Model6.mat','file') == 0
    Model.DES_VEL = DES_VEL_6;
    Model.case = 2;
    Model6=CSA_Solid_Elements(Model,dir_name,filename,numLines_csa,numLines_primary);
    save('Model6.mat','Model6');
    system(['copy ',[filename,'_cse'],'.bdf ',[filename,'_cse_dv6'],'.bdf']);
else load('Model6.mat'); 
end
%
%% Plot Results
% All results on the center line nodes
set(0,'defaultlinelinewidth',2,'defaultaxesfontsize',13,'defaultaxesfontname','Times');
cl = 78:88;
DOF_x = Model1.DOF(cl,2);
%
figure()
plot(1:33,[Model1.DES_VEL(1:33,4), Model2.DES_VEL(1:33,4), Model3.DES_VEL(1:33,4), ...
           Model4.DES_VEL(1:33,4), Model5.DES_VEL(1:33,4), Model6.DES_VEL(1:33,4)],'-*');
xlabel('Node number','interpreter','latex');
ylabel('$\mathcal{V}_{z}$','interpreter','latex');
legend('B-1','B-2','B-3','B-4','B-5','B-6','location','eastoutside');
grid on;
figure()
plot(133:165,[Model1.DES_VEL(133:165,4), Model2.DES_VEL(133:165,4), Model3.DES_VEL(133:165,4), ...
              Model4.DES_VEL(133:165,4), Model5.DES_VEL(133:165,4), Model6.DES_VEL(133:165,4)],'-o');
xlabel('Node number','interpreter','latex');
ylabel('$\mathcal{V}_{z}$','interpreter','latex');
% title('Design velocities');
legend('T-1','T-2','T-3','T-4','T-5','T-6','location','eastoutside');
grid on;
%
figure()
plot(DOF_x,Model3.DISP_LOCAL(cl,3),'b+');
hold on;
plot(DOF_x,Model4.DISP_LOCAL(cl,3),'r^');
plot(DOF_x,Model3.DISP_CONV_TERM(cl,3),'msq');
plot(DOF_x,Model4.DISP_CONV_TERM(cl,3),'c.');
xlabel('x [m]','interpreter','latex');
ylabel('$w^{\prime}$','interpreter','latex');
title('Local Derivative of transverse displacement');
legend('Local, dv-3','Local, dv-4','Conv. dv-3','Conv. dv-4','location','sw');
grid on;
% load('TOTAL_FD_BEST.mat');
%
% TOTAL_SOL200 = [ 0.0000E+00  0.0000E+00  0.0000E+00  0.0000E+00  0.0000E+00  0.0000E+00  
%                 -1.9986E-04 -1.9986E-04  1.9466E-05  1.9466E-05  1.6360E-05  1.6360E-05
%                 -6.7260E-04 -6.7260E-04  3.2204E-05  3.2204E-05  4.5842E-05  4.5842E-05
%                 -1.4083E-03 -1.4083E-03 -1.4108E-06 -1.4108E-06  7.4856E-05  7.4856E-05
%                 -2.3642E-03 -2.3642E-03 -1.1167E-04 -1.1167E-04  8.0602E-05  8.0602E-05
%                 -3.5111E-03 -3.5111E-03 -3.1113E-04 -3.1113E-04  4.1968E-05  4.1968E-05
%                 -4.8175E-03 -4.8175E-03 -6.0674E-04 -6.0674E-04 -6.0644E-05 -6.0644E-05
%                 -6.2513E-03 -6.2513E-03 -9.9904E-04 -9.9904E-04 -2.4278E-04 -2.4278E-04
%                 -7.7814E-03 -7.7814E-03 -1.4848E-03 -1.4848E-03 -5.1635E-04 -5.1635E-04
%                 -9.3741E-03 -9.3741E-03 -2.0586E-03 -2.0586E-03 -8.9109E-04 -8.9109E-04
%                 -1.0999E-02 -1.0999E-02 -2.6922E-03 -2.6922E-03 -1.3405E-03 -1.3405E-03];
%
TOTAL_SOL200 = [ 0.0000E+00  0.0000E+00  0.0000E+00  0.0000E+00  0.0000E+00  0.0000E+00  
                -1.6122E-04 -1.6122E-04  2.7659E-06  2.7659E-06  5.7554E-06  5.7554E-06
                -6.2610E-04 -6.2610E-04 -7.8779E-06 -7.8779E-06  1.6922E-05  1.6922E-05
                -1.3536E-03 -1.3536E-03 -6.7716E-05 -6.7716E-05  2.0174E-05  2.0174E-05
                -2.3037E-03 -2.3037E-03 -2.0053E-04 -2.0053E-04 -1.5190E-06 -1.5190E-06
                -3.4433E-03 -3.4433E-03 -4.1617E-04 -4.1617E-04 -6.4556E-05 -6.4556E-05
                -4.7426E-03 -4.7426E-03 -7.1924E-04 -7.1924E-04 -1.8351E-04 -1.8351E-04
                -6.1696E-03 -6.1696E-03 -1.1083E-03 -1.1083E-03 -3.6911E-04 -3.6911E-04
                -7.6924E-03 -7.6924E-03 -1.5774E-03 -1.5774E-03 -6.2714E-04 -6.2714E-04
                -9.2779E-03 -9.2779E-03 -2.1171E-03 -2.1171E-03 -9.6112E-04 -9.6112E-04
                -1.0896E-02 -1.0896E-02 -2.7029E-03 -2.7029E-03 -1.3481E-03 -1.3481E-03];
load('Results_Airy.mat');
xbar = DOF_x/DOF_x(end);
Airy_total_analytic = -(1/2)*(-3 + xbar).*xbar.^2; %% Obtained from Mathematica
figure()
subplot(2,3,1)
plot(DOF_x,TOTAL_SOL200(:,1)/TOTAL_SOL200(end,1),'*');
hold on;
% plot(DOF_x,TOTAL_FD_BEST(cl,1)/TOTAL_SOL200(end,1),'ro');
plot(DOF_x,Model1.DISP_TOTAL(cl,3)/TOTAL_SOL200(end,1),'gsq');
plot(DOF_x,Model1_Airy.DISP_TOTAL(cl,3)/TOTAL_SOL200(end,1),'ro');
plot(DOF_x,Airy_total_analytic,'md');
legend('SOL 200','CSA - SGR BC','CSA - Airy BC','Analytic (Airy)','location','nw');
% plot(DOF_x,TOTAL_AIRY(:,1)/TOTAL_SOL200(end,1),'g^');
% legend('SOL 200','CSA - SGR','location','nw');
% legend('SOL 200','Finite Difference','CSA','Airy BC','location','nw');
title('Des. Var. 1');
ylabel('Dw/Db on center line');
%
subplot(2,3,2)
plot(DOF_x,TOTAL_SOL200(:,2)/TOTAL_SOL200(end,2),'*');
hold on;
% plot(DOF_x,TOTAL_FD_BEST(cl,2)/TOTAL_SOL200(end,2),'ro');
plot(DOF_x,Model2.DISP_TOTAL(cl,3)/TOTAL_SOL200(end,2),'gsq');
plot(DOF_x,Model2_Airy.DISP_TOTAL(cl,3)/TOTAL_SOL200(end,2),'ro');
plot(DOF_x,Airy_total_analytic,'md');
% plot(DOF_x,TOTAL_AIRY(:,2)/TOTAL_SOL200(end,1),'g^');
title('Des. Var. 2');
%
subplot(2,3,3)
plot(DOF_x,TOTAL_SOL200(:,3)/TOTAL_SOL200(end,3),'*');
hold on;
% plot(DOF_x,TOTAL_FD_BEST(cl,3)/TOTAL_SOL200(end,3),'ro');
plot(DOF_x,Model3.DISP_TOTAL(cl,3)/TOTAL_SOL200(end,3),'gsq');
plot(DOF_x,Model3_Airy.DISP_TOTAL(cl,3)/TOTAL_SOL200(end,3),'ro');
title('Des. Var. 3');
%
subplot(2,3,4)
plot(DOF_x,TOTAL_SOL200(:,4)/TOTAL_SOL200(end,4),'*');
hold on;
% plot(DOF_x,TOTAL_FD_BEST(cl,4)/TOTAL_SOL200(end,4),'ro');
plot(DOF_x,Model4.DISP_TOTAL(cl,3)/TOTAL_SOL200(end,4),'gsq');
plot(DOF_x,Model4_Airy.DISP_TOTAL(cl,3)/TOTAL_SOL200(end,4),'ro');
title('Des. Var. 4');
ylabel('Dw/Db on center line');
xlabel('x [m]');
%
subplot(2,3,5)
plot(DOF_x,TOTAL_SOL200(:,5)/TOTAL_SOL200(end,5),'*');
hold on;
% plot(DOF_x,TOTAL_FD_BEST(cl,5)/TOTAL_SOL200(end,5),'ro');
plot(DOF_x,Model5.DISP_TOTAL(cl,3)/TOTAL_SOL200(end,5),'gsq');
plot(DOF_x,Model5_Airy.DISP_TOTAL(cl,3)/TOTAL_SOL200(end,5),'ro');
title('Des. Var. 5');
xlabel('x [m]');
%
subplot(2,3,6)
plot(DOF_x,TOTAL_SOL200(:,6)/TOTAL_SOL200(end,6),'*');
hold on;
% plot(DOF_x,TOTAL_FD_BEST(cl,6)/TOTAL_SOL200(end,6),'ro');
plot(DOF_x,Model6.DISP_TOTAL(cl,3)/TOTAL_SOL200(end,6),'gsq');
plot(DOF_x,Model6_Airy.DISP_TOTAL(cl,3)/TOTAL_SOL200(end,6),'ro');
title('Des. Var. 6');
xlabel('x [m]');
%
figure()
subplot(1,2,1)
plot(DOF_x,TOTAL_SOL200(:,1),'*');
hold on;
% plot(DOF_x,TOTAL_FD_BEST(cl,3)/TOTAL_SOL200(end,3),'ro');
plot(DOF_x,Model1.DISP_TOTAL(cl,3),'sq');
title('Des. Var. 1');
ylabel('Dw/Db on center line');
xlabel('x [m]');
legend('SOL 200','CSA','location','nw');
%
subplot(1,2,2)
plot(DOF_x,TOTAL_SOL200(:,2),'*');
hold on;
% plot(DOF_x,TOTAL_FD_BEST(cl,4)/TOTAL_SOL200(end,4),'ro');
plot(DOF_x,Model2.DISP_TOTAL(cl,3),'sq');
title('Des. Var. 2');
ylabel('Dw/Db on center line');
xlabel('x [m]');
%
figure()
plot(1:33,[(Model1.dSTRESS(1:33,6,3)).*(Model1.DES_VEL(1:33,4)),(Model1.dSTRESS(1:33,3,3)).*(Model1.DES_VEL(1:33,4))],'*')
hold on;
% plot(1:33,[mean(Model1.dSTRESS(1:33,6,3))*ones(33,1),mean(Model1.dSTRESS(1:33,3,3))*ones(33,1)])
plot(1:33,[-18.5*ones(33,1).*(Model1.DES_VEL(1:33,4)),zeros(33,1)],'-sq');
xlabel('Node numbers');ylabel('CSA Loads');
title('Comparison of SGR-BC loads with Airy-BC loads - dv.1');
legend('SGR-BC loads \sigma^{\prime}_{zx}','SGR-BC loads \sigma^{\prime}_{zz}', ...
       'Airy-BC loads \sigma^{\prime}_{zx}','Airy-BC loads \sigma^{\prime}_{zz}','location','eastoutside');
%
figure()
plot(133:165,[-(Model2.dSTRESS(133:165,6,3)).*(Model2.DES_VEL(133:165,4)),-(Model2.dSTRESS(133:165,3,3)).*(Model2.DES_VEL(133:165,4))],'*')
hold on;
% plot(133:165,[mean(Model2.dSTRESS(133:165,6,3))*ones(33,1),mean(Model2.dSTRESS(133:165,3,3))*ones(33,1)])
plot(133:165,[18.5*ones(33,1).*(Model2.DES_VEL(133:165,4))*-1,zeros(33,1)],'-sq');
xlabel('Node numbers');ylabel('CSA Loads');
title('Comparison of SGR-BC loads with Airy-BC loads - dv.2');
legend('SGR-BC loads \sigma^{\prime}_{zx}','SGR-BC loads \sigma^{\prime}_{zz}', ...
       'Airy-BC loads \sigma^{\prime}_{zx}','Airy-BC loads \sigma^{\prime}_{zz}','location','eastoutside');
%Plotting design velocitieis at the tip face
figure()
plot(Model1.DOF(22:33:end,4),Model1.DES_VEL(22:33:end,4),'r'); hold on;
plot(Model1.DOF(22:33:end,4),Model3.DES_VEL(22:33:end,4),'b');
plot(Model1.DOF(22:33:end,4),Model5.DES_VEL(22:33:end,4),'g');
legend('DV1 - const.','DV3 - lin.','DV5 - cubic');
xlabel('z [m]'); ylabel('z-Design Velocity');
title('z-Design Velocities');   
%
% den = repmat(TOTAL_SOL200(end,:),size(TOTAL_SOL200,1),1);
% figure()
% plot(DOF_x,TOTAL_SOL200./den,'*');
% hold on;
% plot(DOF_x,[Model1.DISP_TOTAL(cl,3),Model2.DISP_TOTAL(cl,3),Model3.DISP_TOTAL(cl,3), ...
%            Model4.DISP_TOTAL(cl,3),Model5.DISP_TOTAL(cl,3),Model6.DISP_TOTAL(cl,3)]./den,'sq');
% xlabel('x [m]','interpreter','latex');
% ylabel('$\dot{w}/\dot{w}_{tip}$','interpreter','latex');
% title('Total Derivative of transverse displacement');
% legend('SOL200, dv1','SOL200, dv2','SOL200, dv3','SOL200, dv4','SOL200, dv5','SOL200, dv6',...
%        'CSA, dv1','CSA, dv2','CSA, dv3','CSA, dv4','CSA, dv5','CSA, dv6','location','sw');
% grid on;
% chk_mat = [(78:88).',Model1.DISP_TOTAL(cl,3),Model2.DISP_TOTAL(cl,3),TOTAL_SOL200(:,1)]