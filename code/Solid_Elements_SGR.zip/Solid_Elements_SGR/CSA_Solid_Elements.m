%% CSA for Solid Element Nastran Model
function Model=CSA_Solid_Elements(Model,dir_name,filename,numLines_csa,numLines_primary)
DOF = Model.DOF;
% CONN = Model.CONN;
% 
%% Primary analysis
% Call Nastran with the model data
if exist([dir_name,'\',filename,'.pch'],'file') == 0
%     cd(dir_name);
    system(['nastran DELETE=IFPDAT SCR=YES OLD=NO NEWS=NO MEMORY=MAX ',filename,'.bdf']);
%     cd('..');
end
%
% Run analysis for Nodal stresses
filename_nodal_stress = [filename,'_nodal_stress'];
if exist([dir_name,'\',filename_nodal_stress,'.pch'],'file') == 0
    system(['copy ',[dir_name,'\',filename],'.bdf ',[dir_name,'\',filename_nodal_stress],'.bdf']);
    fid = fopen([filename_nodal_stress,'.bdf'],'r');
    mydata = cell(1,numLines_primary);
    for k = 1:numLines_primary
        mydata{k} = fgetl(fid);
        if length(mydata{k})>=6
            FirstSixChars = mydata{k}(1:6);
            if strcmp(FirstSixChars,'PSOLID')==1
                mydata{k} = 'PSOLID         1       1       0       0       0       0';
            end
        end
    end
    fclose(fid);
    %
    fid = fopen([filename_nodal_stress,'.bdf'],'w');
    fprintf(fid, '%s\n', mydata{:});
    fclose(fid);
    %
    system(['nastran DELETE=IFPDAT SCR=YES OLD=NO NEWS=NO MEMORY=MAX ',filename_nodal_stress,'.bdf']);
end
%% Parse output file
[DISP,ELEM_DATA] = read_punch(Model,[dir_name,'\',filename]);
Model.DISP = DISP;
Model.ELEM_DATA = ELEM_DATA;
% Parse output and store stress at nodes
[~,ELEM_DATA_NODAL] = read_punch(Model,[dir_name,'\',filename_nodal_stress]);
for el_num = 1:length(ELEM_DATA)
    Model.ELEM_DATA(1,el_num).NODALSTR = ELEM_DATA_NODAL(1,el_num).GAUSSSTR;
end


%% SGR
%
[dDISP,dSTRESS,NSTRESS] = SGR_3D(Model);
%
% % Check Airy Stress Solution
% dSTRESS = zeros(165,6,3);
% dSTRESS(1:33,6,3) = -18.5*ones(33,1);
% dSTRESS(133:165,6,3) = 18.5*ones(33,1);

Model.dDISP = dDISP;
Model.dSTRESS = dSTRESS;
Model.NSTRESS = NSTRESS;
%% Design Velocity
% Model.DES_VEL = DES_VEL;
%% Create model for CSA and run
filename_cse = [filename,'_cse'];
system(['copy ',[dir_name,'\',filename],'.bdf ',[dir_name,'\',filename_cse],'.bdf']);
Apply_BC_Loads_CSE([dir_name,'\',filename_cse],Model,numLines_csa);
% Call Nastran
% cd(dir_name);
system(['nastran DELETE=IFPDAT SCR=YES OLD=NO NEWS=NO MEMORY=MAX ',filename_cse,'.bdf']);
% cd('..');
%% Parse output to get CSA Local Derivative
[DISP_LOCAL,ELEM_DATA_LOCAL] = read_punch(Model,[dir_name,'\',filename_cse]);
Model.DISP_LOCAL = DISP_LOCAL;
Model.ELEM_DATA_LOCAL = ELEM_DATA_LOCAL;
%% Compute CSA Total Derivative
dDISPdx = Model.dDISP(:,:,1);
dDISPdy = Model.dDISP(:,:,2);
dDISPdz = Model.dDISP(:,:,3);
Des_Vel_X = repmat(Model.DES_VEL(:,2),1,size(dDISPdx,2));
Des_Vel_Y = repmat(Model.DES_VEL(:,3),1,size(dDISPdy,2));
Des_Vel_Z = repmat(Model.DES_VEL(:,4),1,size(dDISPdz,2));
Model.DISP_CONV_TERM = dDISPdx.*Des_Vel_X + dDISPdy.*Des_Vel_Y + dDISPdz.*Des_Vel_Z;
DISP_TOTAL = DISP_LOCAL + Model.DISP_CONV_TERM;
%
% At the SPCed nodes, add convective term only when Design Velocity is not parallel to the surface
SPC=Model.SPC;
SPC_Normal_order = Model.SPC_Normal_order;
DES_VEL = Model.DES_VEL;
SPC_Normal = zeros(size(SPC_Normal_order,1),4);      
for i=1:size(SPC_Normal_order,1)
    SPC_Normal(i,1) = SPC_Normal_order(i,1);
    t1 = [DOF(SPC_Normal_order(i,3),2) , DOF(SPC_Normal_order(i,3),3) , DOF(SPC_Normal_order(i,3),4)] - ...
         [DOF(SPC_Normal_order(i,2),2) , DOF(SPC_Normal_order(i,2),3) , DOF(SPC_Normal_order(i,2),4)];
    t2 = [DOF(SPC_Normal_order(i,5),2) , DOF(SPC_Normal_order(i,5),3) , DOF(SPC_Normal_order(i,5),4)] - ...
         [DOF(SPC_Normal_order(i,2),2) , DOF(SPC_Normal_order(i,2),3) , DOF(SPC_Normal_order(i,2),4)];
    n = cross(t1,t2);
    SPC_Normal(i,2:4) = n/norm(n,2);
end          
%
for node = 1:size(SPC,1)
    node_id = SPC(node,1);
    for j = 1:3
        comp = SPC(node,j+1); % component at which SPC is applied
        if comp~=0
            DISP_TOTAL(node_id,comp) = DISP_LOCAL(node_id,comp);
            SPC_Normal_vec = SPC_Normal(node,2:4).';
            Des_Vel_vec = [DES_VEL(node_id,2);DES_VEL(node_id,3);DES_VEL(node_id,4)];
            if abs(dot(Des_Vel_vec/norm(Des_Vel_vec,2),SPC_Normal_vec))>1e-10
                DISP_TOTAL(node_id,comp) = DISP_LOCAL(node_id,comp) + ...
                                           dDISPdx(node_id,comp)*Des_Vel_X(node_id,comp) + ...
                                           dDISPdy(node_id,comp)*Des_Vel_Y(node_id,comp) + ...
                                           dDISPdz(node_id,comp)*Des_Vel_Z(node_id,comp);
            end
        end
    end
end
%
Model.DISP_TOTAL = DISP_TOTAL;
end