function Apply_BC_Loads_CSE(filename_cse,Model,numLines)
% numLines = 365;
dDISP = Model.dDISP;
dSTRESS = Model.dSTRESS;
DOF = Model.DOF;
Des_Vel = Model.DES_VEL;
Normal_order = Model.Normal_order;
SPC = Model.SPC;
SPC_Normal_order = Model.SPC_Normal_order;
NSTRESS = Model.NSTRESS;

% SPC =       [1     0     2     3
%             12     0     2     3
%             23     0     2     3
%             34     0     2     3
%             45     1     2     3
%             56     0     2     3
%             67     1     2     3
%             78     1     2     3
%             89     1     2     3
%            100     0     2     3
%            111     1     2     3
%            122     0     2     3
%            133     0     2     3
%            144     0     2     3
%            155     0     2     3];

dDISPdx = dDISP(:,:,1);
dDISPdy = dDISP(:,:,2);
dDISPdz = dDISP(:,:,3);
dSTRESSdx = dSTRESS(:,:,1);
dSTRESSdy = dSTRESS(:,:,2);
dSTRESSdz = dSTRESS(:,:,3);

Normal = zeros(size(Normal_order,1),4);
Normal_new = zeros(size(Normal_order,1),4);
Normal_dot = zeros(size(Normal_order,1),4);
%
delta_b = 1i*1e-16;
DOF_new(:,1) = DOF(:,1);
DOF_new(:,2:4) = DOF(:,2:4) + Des_Vel(:,2:4)*delta_b;
for i=1:size(Normal_order,1)
    Normal(i,1) = Normal_order(i,1);
    t1 = [DOF(Normal_order(i,3),2) , DOF(Normal_order(i,3),3) , DOF(Normal_order(i,3),4)] - ...
         [DOF(Normal_order(i,2),2) , DOF(Normal_order(i,2),3) , DOF(Normal_order(i,2),4)];
    t2 = [DOF(Normal_order(i,5),2) , DOF(Normal_order(i,5),3) , DOF(Normal_order(i,5),4)] - ...
         [DOF(Normal_order(i,2),2) , DOF(Normal_order(i,2),3) , DOF(Normal_order(i,2),4)];
    n = cross(t1,t2);
    Normal(i,2:4) = n/norm(n,2);
    %
    Normal_new(i,1) = Normal_order(i,1);
    t1 = [DOF_new(Normal_order(i,3),2) , DOF_new(Normal_order(i,3),3) , DOF_new(Normal_order(i,3),4)] - ...
         [DOF_new(Normal_order(i,2),2) , DOF_new(Normal_order(i,2),3) , DOF_new(Normal_order(i,2),4)];
    t2 = [DOF_new(Normal_order(i,5),2) , DOF_new(Normal_order(i,5),3) , DOF_new(Normal_order(i,5),4)] - ...
         [DOF_new(Normal_order(i,2),2) , DOF_new(Normal_order(i,2),3) , DOF_new(Normal_order(i,2),4)];
    n = cross(t1,t2);
    Normal_new(i,2:4) = n/sqrt(n*n.');
    %
    Normal_dot(i,1) = Normal_order(i,1);
    Normal_dot(i,2:4) = imag(Normal_new(i,2:4))/imag(delta_b);
end

SPC_Normal = zeros(size(SPC_Normal_order,1),4);      
for i=1:size(SPC_Normal_order,1)
    SPC_Normal(i,1) = SPC_Normal_order(i,1);
    t1 = [DOF(SPC_Normal_order(i,3),2) , DOF(SPC_Normal_order(i,3),3) , DOF(SPC_Normal_order(i,3),4)] - ...
         [DOF(SPC_Normal_order(i,2),2) , DOF(SPC_Normal_order(i,2),3) , DOF(SPC_Normal_order(i,2),4)];
    t2 = [DOF(SPC_Normal_order(i,5),2) , DOF(SPC_Normal_order(i,5),3) , DOF(SPC_Normal_order(i,5),4)] - ...
         [DOF(SPC_Normal_order(i,2),2) , DOF(SPC_Normal_order(i,2),3) , DOF(SPC_Normal_order(i,2),4)];
    n = cross(t1,t2);
    SPC_Normal(i,2:4) = n/norm(n,2);
end

filename_cse = [filename_cse,'.bdf'];
fid = fopen(filename_cse,'r');
mydata = cell(1, numLines);
for k = 1:numLines
    mydata{k} = fgetl(fid);
end
fclose(fid);

line_number = numLines;

%% CSA fprime loads on the tip face
mydata{line_number} = '$ CSA Fprime Loads on tip face';
line_number = line_number+1;
%
F = -100;
b = 2;
h = 4;
% des_vel_1 = @(z) (1 - z/h);
% des_vel_2 = @(z) -z/h;
% traction = @(z) 6*F*z/(b*h^2) - 6*F*z^2/(b*h^3);
traction_fdot = @(z) 6*F*(z/h)*(1-z/h)/(b*h^2);
traction_dfdz = @(z) 6*F/(b*h^2) - 12*F*z/(b*h^3);
traction_fprime = @(z,dv) traction_fdot(z) - traction_dfdz(z)*dv;
nx = 10;
ny = 2;
nz = 4;
dely = nx+1;
delz = (nx+1)*(ny+1);
PLOAD_fprime = zeros((ny+1)*(nz+1),2);
ctr = 0;
for k = 1:nz+1
    for j = 1:ny+1
        ctr = ctr + 1;
        node_id = (nx+1) + (j-1)*dely + (k-1)*delz;
        node_z = DOF(node_id,4);
        dv = Des_Vel(node_id,4);
        PLOAD_fprime(ctr,:) = [node_id,traction_fprime(node_z,dv)];
    end
end
%
Tip_face = [ 10, 11, 22, 55, 44
             20, 22, 33, 66, 55
             30, 44, 55, 88, 77
             40, 55, 66, 99, 88
             50, 77, 88, 121, 110
             60, 88, 99, 132, 121             
             70, 110, 121, 154, 143
             80, 121, 132, 165, 154];
%
for ctr = 1:size(Tip_face,1)
    node1 = Tip_face(ctr,2);
    node2 = Tip_face(ctr,3);
    node3 = Tip_face(ctr,4);
    node4 = Tip_face(ctr,5);
    [~,node_ind] = ismember(node1,PLOAD_fprime(:,1));
    t1 = PLOAD_fprime(node_ind,2);
    [~,node_ind] = ismember(node2,PLOAD_fprime(:,1));
    t2 = PLOAD_fprime(node_ind,2);
    [~,node_ind] = ismember(node3,PLOAD_fprime(:,1));
    t3 = PLOAD_fprime(node_ind,2);
    [~,node_ind] = ismember(node4,PLOAD_fprime(:,1));
    t4 = PLOAD_fprime(node_ind,2);
    mydata{line_number} = ['PLOAD4,1,',num2str(Tip_face(ctr,1),'%8d'),',',...
        num2str(t1,'%16.10e'),',',...
        num2str(t2,'%16.10e'),',',...
        num2str(t3,'%16.10e'),',',...
        num2str(t4,'%16.10e'),',',...
        num2str(Tip_face(ctr,2),'%8d'),',',...
        num2str(Tip_face(ctr,4),'%8d')];
    mydata{line_number+1} = ',0,0.0,0.0,1.0';
    %
    line_number = line_number+2;
end

%% Loop over boundary elements and write load for each boundary face
mydata{line_number} = '$ CSA Loads for Stress';
line_number = line_number+1;
%
for e = 1:size(Normal_order,1)
    elem = Normal_order(e,1);
    CSATraction_vec_node = zeros(3,4);
    Normal_vec = Normal(e,2:4).';
    Normal_vec_dot = Normal_dot(e,2:4).';
    for node = 1:4
        node_id = Normal_order(e,node+1);
        Des_Vel_vec = [Des_Vel(node_id,2);Des_Vel(node_id,3);Des_Vel(node_id,4)];
        no_cse_load_flag = [];
        if abs(dot(Des_Vel_vec/norm(Des_Vel_vec,2),Normal_vec))>1e-10
            dSigmadx = [dSTRESSdx(node_id,1) , dSTRESSdx(node_id,4) , dSTRESSdx(node_id,6);
                        dSTRESSdx(node_id,4) , dSTRESSdx(node_id,2) , dSTRESSdx(node_id,5);
                        dSTRESSdx(node_id,6) , dSTRESSdx(node_id,5) , dSTRESSdx(node_id,3)];
            dSigmady = [dSTRESSdy(node_id,1) , dSTRESSdy(node_id,4) , dSTRESSdy(node_id,6);
                        dSTRESSdy(node_id,4) , dSTRESSdy(node_id,2) , dSTRESSdy(node_id,5);
                        dSTRESSdy(node_id,6) , dSTRESSdy(node_id,5) , dSTRESSdy(node_id,3)];
            dSigmadz = [dSTRESSdz(node_id,1) , dSTRESSdz(node_id,4) , dSTRESSdz(node_id,6);
                        dSTRESSdz(node_id,4) , dSTRESSdz(node_id,2) , dSTRESSdz(node_id,5);
                        dSTRESSdz(node_id,6) , dSTRESSdz(node_id,5) , dSTRESSdz(node_id,3)];
            %
            CSATraction_vec_node_x = -Des_Vel(node_id,2)*dSigmadx*Normal_vec;
            CSATraction_vec_node_y = -Des_Vel(node_id,3)*dSigmady*Normal_vec;
            CSATraction_vec_node_z = -Des_Vel(node_id,4)*dSigmadz*Normal_vec;
            CSATraction_vec_node(:,node) = CSATraction_vec_node(:,node) + CSATraction_vec_node_x + CSATraction_vec_node_y + CSATraction_vec_node_z;
            no_cse_load_flag = 0;
        end
        if norm(Normal_vec_dot,2)>1e-3
            Sigma = [NSTRESS(node_id,1) , NSTRESS(node_id,4) , NSTRESS(node_id,6);
                     NSTRESS(node_id,4) , NSTRESS(node_id,2) , NSTRESS(node_id,5);
                     NSTRESS(node_id,6) , NSTRESS(node_id,5) , NSTRESS(node_id,3)];
%             [~,row] = intersect(Model.ELEM_DATA(1,elem).CONNEC,node_id);
%             Sigma = [Model.ELEM_DATA(1,elem).NODALSTR(row,1) , Model.ELEM_DATA(1,elem).NODALSTR(row,4) , Model.ELEM_DATA(1,elem).NODALSTR(row,6);
%                      Model.ELEM_DATA(1,elem).NODALSTR(row,4) , Model.ELEM_DATA(1,elem).NODALSTR(row,2) , Model.ELEM_DATA(1,elem).NODALSTR(row,5);
%                      Model.ELEM_DATA(1,elem).NODALSTR(row,6) , Model.ELEM_DATA(1,elem).NODALSTR(row,5) , Model.ELEM_DATA(1,elem).NODALSTR(row,3)];
            CSATraction_vec_node(:,node) = CSATraction_vec_node(:,node) - Sigma*Normal_vec_dot;
            no_cse_load_flag = 0;
        end
        if no_cse_load_flag ~= 0
            no_cse_load_flag = 1;
            break;
        end
    end
    if no_cse_load_flag == 1
        continue;
    end
    % White to BDF file
    % X Loading
    mydata{line_number} = ['PLOAD4,1,',num2str(Normal_order(e,1),'%8d'),',',...
                           num2str(CSATraction_vec_node(1,1),'%16.10e'),',',...
                           num2str(CSATraction_vec_node(1,2),'%16.10e'),',',...
                           num2str(CSATraction_vec_node(1,3),'%16.10e'),',',...
                           num2str(CSATraction_vec_node(1,4),'%16.10e'),',',...
                           num2str(Normal_order(e,2),'%8d'),',',...
                           num2str(Normal_order(e,4),'%8d')];
    mydata{line_number+1} = ',0,1.0,0.0,0.0';
    % Y Loading
    mydata{line_number+2} = ['PLOAD4,1,',num2str(Normal_order(e,1),'%8d'),',',...
                           num2str(CSATraction_vec_node(2,1),'%16.10e'),',',...
                           num2str(CSATraction_vec_node(2,2),'%16.10e'),',',...
                           num2str(CSATraction_vec_node(2,3),'%16.10e'),',',...
                           num2str(CSATraction_vec_node(2,4),'%16.10e'),',',...
                           num2str(Normal_order(e,2),'%8d'),',',...
                           num2str(Normal_order(e,4),'%8d')];
    mydata{line_number+3} = ',0,0.0,1.0,0.0';
    % Z Loading
    mydata{line_number+4} = ['PLOAD4,1,',num2str(Normal_order(e,1),'%8d'),',',...
                           num2str(CSATraction_vec_node(3,1),'%16.10e'),',',...
                           num2str(CSATraction_vec_node(3,2),'%16.10e'),',',...
                           num2str(CSATraction_vec_node(3,3),'%16.10e'),',',...
                           num2str(CSATraction_vec_node(3,4),'%16.10e'),',',...
                           num2str(Normal_order(e,2),'%8d'),',',...
                           num2str(Normal_order(e,4),'%8d')];
    mydata{line_number+5} = ',0,0.0,0.0,1.0';
    %
    line_number = line_number+6;
end

%% CSA displacement loads
% SPCD,1,G1,C1,D1
mydata{line_number} = '$ CSA Loads for Displacements';
line_number = line_number+1;
%
for node = 1:size(SPC,1)
    node_id = SPC(node,1);
    for j = 1:3
        comp = SPC(node,j+1); % component at which SPC is applied
        if comp~=0
            SPC_Normal_vec = SPC_Normal(node,2:4).';
            Des_Vel_vec = [Des_Vel(node_id,2);Des_Vel(node_id,3);Des_Vel(node_id,4)];
            if abs(dot(Des_Vel_vec/norm(Des_Vel_vec,2),SPC_Normal_vec))>1e-10
                d_prime = -1*dDISPdx(node_id,comp)*Des_Vel(node_id,2) ...
                          -1*dDISPdy(node_id,comp)*Des_Vel(node_id,3) ...
                          -1*dDISPdz(node_id,comp)*Des_Vel(node_id,4);
                mydata{line_number} = ['SPCD,1,',num2str(node_id,'%8d'),',',...
                                       num2str(comp,'%8d'),',',...
                                       num2str(d_prime,'%16.10e')];
                line_number = line_number+1;
            end
        end
    end
end
%
% if Model.case == 1
%     mydata{line_number}    = '$ TRACTIONS for fprime case 1';
%     mydata{line_number+1}  = 'PLOAD4,1,10,1.8750000000e+01,1.8750000000e+01,3.5156250000e+00,3.5156250000e+00,11,55';
%     mydata{line_number+2}  = ',0,0.0,0.0,1.0';
%     mydata{line_number+3}  = 'PLOAD4,1,20,1.8750000000e+01,1.8750000000e+01,3.5156250000e+00,3.5156250000e+00,22,66';
%     mydata{line_number+4}  = ',0,0.0,0.0,1.0';
%     mydata{line_number+5}  = 'PLOAD4,1,30,3.5156250000e+00,3.5156250000e+00,-4.6875000000e+00,-4.6875000000e+00,44,88';
%     mydata{line_number+6}  = ',0,0.0,0.0,1.0';
%     mydata{line_number+7}  = 'PLOAD4,1,40,3.5156250000e+00,3.5156250000e+00,-4.6875000000e+00,-4.6875000000e+00,55,99';
%     mydata{line_number+8}  = ',0,0.0,0.0,1.0';
%     mydata{line_number+9}  = 'PLOAD4,1,50,-4.6875000000e+00,-4.6875000000e+00,-5.8593750000e+00,-5.8593750000e+00,77,121';
%     mydata{line_number+10} = ',0,0.0,0.0,1.0';
%     mydata{line_number+11} = 'PLOAD4,1,60,-4.6875000000e+00,-4.6875000000e+00,-5.8593750000e+00,-5.8593750000e+00,88,132';
%     mydata{line_number+12} = ',0,0.0,0.0,1.0';
%     mydata{line_number+13} = 'PLOAD4,1,70,-5.8593750000e+00,-5.8593750000e+00,0.0000000000e+00,0.0000000000e+00,110,154';
%     mydata{line_number+14} = ',0,0.0,0.0,1.0';
%     mydata{line_number+15} = 'PLOAD4,1,80,-5.8593750000e+00,-5.8593750000e+00,0.0000000000e+00,0.0000000000e+00,121,165';
%     mydata{line_number+16} = ' ,0,0.0,0.0,1.0';
% elseif Model.case == 2
%     mydata{line_number}    = '$ TRACTIONS for fprime case 2';
%     mydata{line_number+1}  = 'PLOAD4,1,10,0.0000000000e+00,0.0000000000e+00,-5.8593750000e+00,-5.8593750000e+00,11,55';
%     mydata{line_number+2}  = ',0,0.0,0.0,1.0';
%     mydata{line_number+3}  = 'PLOAD4,1,20,0.0000000000e+00,0.0000000000e+00,-5.8593750000e+00,-5.8593750000e+00,22,66';
%     mydata{line_number+4}  = ',0,0.0,0.0,1.0';
%     mydata{line_number+5}  = 'PLOAD4,1,30,-5.8593750000e+00,-5.8593750000e+00,-4.6875000000e+00,-4.6875000000e+00,44,88';
%     mydata{line_number+6}  = ',0,0.0,0.0,1.0';
%     mydata{line_number+7}  = 'PLOAD4,1,40,-5.8593750000e+00,-5.8593750000e+00,-4.6875000000e+00,-4.6875000000e+00,55,99';
%     mydata{line_number+8}  = ',0,0.0,0.0,1.0';
%     mydata{line_number+9}  = 'PLOAD4,1,50,-4.6875000000e+00,-4.6875000000e+00,3.5156250000e+00,3.5156250000e+00,77,121';
%     mydata{line_number+10} = ',0,0.0,0.0,1.0';
%     mydata{line_number+11} = 'PLOAD4,1,60,-4.6875000000e+00,-4.6875000000e+00,3.5156250000e+00,3.5156250000e+00,88,132';
%     mydata{line_number+12} = ',0,0.0,0.0,1.0';
%     mydata{line_number+13} = 'PLOAD4,1,70,3.5156250000e+00,3.5156250000e+00,1.8750000000e+01,1.8750000000e+01,110,154';
%     mydata{line_number+14} = ',0,0.0,0.0,1.0';
%     mydata{line_number+15} = 'PLOAD4,1,80,3.5156250000e+00,3.5156250000e+00,1.8750000000e+01,1.8750000000e+01,121,165';
%     mydata{line_number+16} = ',0,0.0,0.0,1.0';	
% end
% line_number = line_number + 17;
%
mydata{line_number} = '$';
mydata{line_number+1} = 'ENDDATA';
%
fid = fopen(filename_cse,'w');
fprintf(fid, '%s\n', mydata{:});
fclose(fid);


end